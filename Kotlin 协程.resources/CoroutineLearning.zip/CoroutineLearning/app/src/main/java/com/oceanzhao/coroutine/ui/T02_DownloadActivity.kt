package com.oceanzhao.coroutine.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.Observer
import androidx.lifecycle.lifecycleScope
import com.oceanzhao.coroutine.R
import com.oceanzhao.coroutine.download.DownloadManager.DownloadStatus.*
import com.oceanzhao.coroutine.utils.alert
import com.oceanzhao.coroutine.utils.toast
import kotlinx.android.synthetic.main.activity_02.*
import kotlinx.coroutines.launch

class T02_DownloadActivity : AppCompatActivity() {

    private val viewModel by viewModels<DownloadViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_02)

        showDialogButton.setOnClickListener {
            lifecycleScope.launch {
                val myChoice = alert("Warning", "Confirm do this?")
                Toast.makeText(this@T02_DownloadActivity,"My choice [$myChoice]",Toast.LENGTH_SHORT).show()
            }



            Toast.makeText(this,"My choice [xxxx]",Toast.LENGTH_SHORT).show()
        }


        viewModel.downloadStatus.observe(this, Observer { downloadStatus ->
            when (downloadStatus) {
                null, None -> {
                    downloadButton.isEnabled = true
                    downloadButton.text = "Download"
                    downloadButton.setOnClickListener {
                        viewModel.download(
                            "https://kotlinlang.org/docs/kotlin-reference.pdf",
                            "Kotlin-Docs.pdf"
                        )
                    }
                }
                is Progress -> {
                    downloadButton.isEnabled = false
                    downloadButton.text = "Downloading(${downloadStatus.value})"
                }

                is Error -> {
                    toast(downloadStatus.throwable)
                    downloadButton.isEnabled = true
                    downloadButton.text = "Download Error"
                    downloadButton.setOnClickListener {
                        viewModel.download(
                            "https://kotlinlang.org/docs/kotlin-reference.pdf",
                            "Kotlin-Docs.pdf"
                        )
                    }
                }
                is Done -> {
                    toast(downloadStatus.file)
                    downloadButton.isEnabled = true
                    downloadButton.text = "Open File"
                    downloadButton.setOnClickListener {
                        Intent(Intent.ACTION_VIEW).also {
                            it.setDataAndType(
                                FileProvider.getUriForFile(
                                    this,
                                    "${packageName}.provider",
                                    downloadStatus.file
                                ), "application/pdf"
                            )
                            it.flags =
                                Intent.FLAG_ACTIVITY_NO_HISTORY or Intent.FLAG_GRANT_READ_URI_PERMISSION
                        }.also(::startActivity)
                    }
                }
            }
        })
    }
}