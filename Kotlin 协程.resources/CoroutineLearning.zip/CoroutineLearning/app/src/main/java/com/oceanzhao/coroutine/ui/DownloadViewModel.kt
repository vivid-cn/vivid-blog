package com.oceanzhao.coroutine.ui

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.oceanzhao.coroutine.download.DownloadManager
import com.oceanzhao.coroutine.download.DownloadManager.DownloadStatus
import com.oceanzhao.coroutine.download.DownloadManager.DownloadStatus.None
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch

class DownloadViewModel : ViewModel() {

    val downloadStatus = MutableLiveData<DownloadStatus>(None)

    fun download(url: String, fileName: String) {
        viewModelScope.launch {
            DownloadManager.download(url, fileName)
                .flowOn(Dispatchers.IO)
                .collect { downloadStatus.value = it }
        }

    }

}