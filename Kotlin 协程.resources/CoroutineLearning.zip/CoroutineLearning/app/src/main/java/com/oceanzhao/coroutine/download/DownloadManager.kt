package com.oceanzhao.coroutine.download

import com.oceanzhao.coroutine.appContext
import com.oceanzhao.coroutine.utils.copyTo
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.logging.HttpLoggingInterceptor
import timber.log.Timber
import java.io.File

object DownloadManager {

    private val okHttpClient =
        OkHttpClient.Builder()
            .addInterceptor(HttpLoggingInterceptor(object : HttpLoggingInterceptor.Logger {
                override fun log(message: String) {
                    Timber.d(message)
                }

            }).also {
                it.level = HttpLoggingInterceptor.Level.BODY
            }).build()
    private val downloadDirectory by lazy {
        File(appContext.filesDir, "download").also {
            it.mkdirs()
        }
    }

    sealed class DownloadStatus {
        object None : DownloadStatus()
        class Progress(val value: Int) : DownloadStatus()
        class Error(val throwable: Throwable) : DownloadStatus()
        class Done(val file: File) : DownloadStatus()
    }

    fun download(url: String, fileName: String): Flow<DownloadStatus> {
        val file = File(downloadDirectory, fileName)
        return flow {
            val request = Request.Builder().url(url).get().build()
            val response = okHttpClient.newCall(request).execute()
            if (response.isSuccessful) {
                response.body!!.let { body ->
                    val total = body.contentLength()
                    var emitted = 0L
                    file.outputStream().use { output ->
                        body.byteStream().use { input ->
                            input.copyTo(output) { copied ->
                                val process = copied * 100 / total
                                if (process - emitted > 5) {
                                    emit(DownloadStatus.Progress(process.toInt()))
                                    emitted = process
                                }
                            }
                        }
                    }

                    emit(DownloadStatus.Done(file))
                }
            } else {
                throw RuntimeException("Download failed.")
            }
        }.catch {
            file.delete()
            emit(DownloadStatus.Error(it))
        }.conflate()
    }


}