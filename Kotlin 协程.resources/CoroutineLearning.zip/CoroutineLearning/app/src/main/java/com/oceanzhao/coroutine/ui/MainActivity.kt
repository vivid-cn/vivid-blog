package com.oceanzhao.coroutine.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.oceanzhao.coroutine.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun click01(view: View) {
        startActivity(Intent(this, T01_NetworkApiActivity::class.java))
    }

    fun click02(view: View) {
        startActivity(Intent(this, T02_DownloadActivity::class.java))
    }
}