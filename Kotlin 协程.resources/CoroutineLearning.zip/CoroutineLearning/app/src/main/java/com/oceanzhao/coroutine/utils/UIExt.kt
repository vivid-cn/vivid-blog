package com.oceanzhao.coroutine.utils

import android.widget.Toast
import com.oceanzhao.coroutine.appContext

fun toast(message: Any?) {
    Toast.makeText(appContext, message.toString(), Toast.LENGTH_LONG).show()
}