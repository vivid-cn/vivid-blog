package com.oceanzhao.coroutine.ui

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.oceanzhao.common.callback.User
import com.oceanzhao.common.utils.Logger
import com.oceanzhao.coroutine.R
import com.oceanzhao.coroutine.callback2suspend.await
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import rx.android.schedulers.AndroidSchedulers
import rx.schedulers.Schedulers
import rx.subscriptions.CompositeSubscription
import com.oceanzhao.common.callback.gitHubServiceApi as callbackApi
import com.oceanzhao.common.coroutine.suspend.gitHubServiceApi as suspendApi
import com.oceanzhao.common.rx.gitHubServiceApi as rxApi

class T01_NetworkApiActivity : AppCompatActivity() {

    private lateinit var tvName: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_01)
        tvName = findViewById(R.id.tv_name)
    }

    fun click11(view: View) {
        clearText()
        callbackApi.getUser("zhy060307").enqueue(object : Callback<User> {
            override fun onFailure(call: Call<User>, t: Throwable) {
                Logger.error(t)
            }

            override fun onResponse(call: Call<User>, response: Response<User>) {
                if (response.isSuccessful) {
                    val user = response.body()
                    Logger.debug(user)
                    runOnUiThread {
                        tvName.text = user!!.name
                    }
                } else {
                    Logger.error("${response.code()} : ${response.errorBody()}")
                }
            }

        })



    }

    fun click01(v:View){
        lifecycleScope.launch {
            val user = callbackApi.getUser("kotlin").await()
            tvName.text = user.name
        }
    }

    private val subscriptions: CompositeSubscription = CompositeSubscription()
    fun useRxJava(view: View) {
        val subscribe = rxApi.getUser("zhy060307")
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe({
                //onSuccess    runOnMainThread
                tvName.text = it.name
            }, {
                //onError
                Logger.error(it)
            })

        subscriptions.add(subscribe)
    }

    override fun onDestroy() {
        super.onDestroy()
        subscriptions.clear()
    }

    private var requsetJab: Job? = null
    fun useCoroutine(view: View) {
        requsetJab?.cancel()
        requsetJab = lifecycleScope.launch {
            try {
                val user = suspendApi.getUser("zhy060307")
                tvName.text = user.name
            } catch (e: Exception) {
                Logger.error(e)
            }
        }

        lifecycleScope.launch {
//            val user = rxApi.getUser("google").await()
        }
    }

    fun click03(view: View) {
        clearText()
        lifecycleScope.launch {
            try {
                val users = arrayOf("zhy060307", "kotlin", "google").map {
                    suspendApi.getUser(it).name
                }.toList()
                tvName.text = users.toString()
            } catch (e: Exception) {
                Logger.error(e)
            }
        }
    }

    private fun clearText() {
        tvName.text = ""
    }
}