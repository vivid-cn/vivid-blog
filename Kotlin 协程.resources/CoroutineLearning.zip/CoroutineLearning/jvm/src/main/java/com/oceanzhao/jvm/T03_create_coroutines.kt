package com.oceanzhao.jvm

import com.oceanzhao.common.utils.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.concurrent.thread
import kotlin.coroutines.*

class T03_create_coroutines {
}

fun main() {
    startCoroutine01()
    Thread.sleep(2000)
}

private fun startCoroutine01() {
    suspend {

        suspendFun1()
        suspendFun1()
        suspendFun1()
        ""
    }.startCoroutine(object : Continuation<String> {
        override val context: CoroutineContext
            get() = EmptyCoroutineContext

        override fun resumeWith(result: Result<String>) {
            println("resumeWith $result")
        }

    })
}

private fun createCoroutine01() {
    suspend {
        suspendFun()
    }.createCoroutine(object : Continuation<String> {
        override val context: CoroutineContext
            get() = EmptyCoroutineContext

        override fun resumeWith(result: Result<String>) {
            println("resumeWith $result")
        }

    }).resume(Unit) //调用resume(Unit)用于启动协程
}

suspend fun suspendFun() = suspendCoroutine<String> {
    //it SafeContinuation
    thread {
        Logger.debug("working hard...")
        it.resume("work done...")
    }

}

suspend fun suspendFun1()= withContext(Dispatchers.Unconfined){
    Logger.debug("suspendFun1 working hard...")
}

