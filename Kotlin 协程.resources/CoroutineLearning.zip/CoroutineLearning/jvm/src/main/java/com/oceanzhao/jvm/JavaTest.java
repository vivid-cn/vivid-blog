package com.oceanzhao.jvm;

import com.oceanzhao.common.coroutine.suspend.GitHubServiceApiKt;

import kotlin.coroutines.Continuation;

public class JavaTest {
    public static void main(String[] args) {
        GitHubServiceApiKt.getGitHubServiceApi().getUser("", null);
    }
}
