package com.oceanzhao.jvm

import com.oceanzhao.common.utils.Logger
import kotlinx.coroutines.CoroutineExceptionHandler
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import kotlin.coroutines.*


private val exceptionHandler =
    CoroutineExceptionHandler { coroutineContext: CoroutineContext, throwable: Throwable ->
        Logger.error(" exceptionHandler "+throwable.message)
    }

suspend fun main() {
    suspend {
        Logger.debug(1)
        Logger.debug(suspendA())
        Logger.debug(2)

    }.startCoroutine(object : Continuation<Any> {
        override val context: CoroutineContext
            get() = MyInterceptor()

        override fun resumeWith(result: Result<Any>) {
            Logger.debug("completion:$result")
        }

    })
    Thread.sleep(1000)
}

suspend fun suspendA() = suspendCoroutine<String> {
    //it SafeContinuation
    thread {
        Logger.debug("working hard...")
        it.resume("work done...")
    }

}

class MyInterceptor : ContinuationInterceptor {

    override val key = ContinuationInterceptor

    override fun <T> interceptContinuation(continuation: Continuation<T>): Continuation<T> {
        return MyContinuation(continuation)
    }
}

class MyContinuation<T>(val continuation: Continuation<T>) : Continuation<T> {
    private val executors = Executors.newFixedThreadPool(1)
    { r: Runnable ->
        Thread(r, "MyInterceptor").apply {
            isDaemon = true
        }
    }
    override val context = continuation.context

    override fun resumeWith(result: Result<T>) {
        Logger.debug("Before Dispatch")
        executors.submit {
            continuation.resumeWith(result)
            Logger.debug("After Dispatch")
        }
    }
}