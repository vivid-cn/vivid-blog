package com.oceanzhao.jvm

import com.oceanzhao.common.callback.User
import com.oceanzhao.common.utils.Logger
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.awt.BorderLayout
import java.awt.event.ActionEvent
import javax.swing.JButton
import javax.swing.JFrame
import javax.swing.SwingUtilities
import com.oceanzhao.common.callback.gitHubServiceApi as callBackApi
import com.oceanzhao.common.coroutine.suspend.gitHubServiceApi as suspendApi
import com.oceanzhao.common.coroutine.deferred.gitHubServiceApi as deferredApi

class MainWindow : JFrame() {
    private val scope = MainScope()
    private val button = JButton("Click me")

    init {
        initThread()
        contentPane.add(button, BorderLayout.NORTH)
        title = "Coroutine@hyzhao"
        setSize(600, 200)
        isResizable = true
        defaultCloseOperation = EXIT_ON_CLOSE
        isVisible = true
    }

    private fun initThread() {
        SwingUtilities.invokeAndWait {
            val oldName = Thread.currentThread().name
            val newName = "Swing Main"
            Thread.currentThread().name = newName
            Logger.error("Change thread name from $oldName to $newName for debug only.")
        }
    }


    fun onButtonClickCommon(l: (ActionEvent) -> Unit) {
        button.addActionListener {
            l(it)
        }
    }

    fun onButtonClickScope(listener: suspend (ActionEvent) -> Unit) {
        button.addActionListener { event ->
            scope.launch { listener(event) }
        }
    }

    fun setButtonText(text: String) {
        button.text = text;
    }
}


fun main() {
    val window = MainWindow()
    showWindowWithCoroutine(window)
}

private fun showWindowWithCallBack(window: MainWindow) {
    window.onButtonClickScope {
        callBackApi.getUser("zhy060307").enqueue(object : Callback<User> {
            override fun onResponse(call: Call<User>, response: Response<User>) {
                if (response.isSuccessful) {
                    SwingUtilities.invokeAndWait {
                        window.setButtonText(response.body()?.name ?: "")
                    }
                }
            }

            override fun onFailure(call: Call<User>, t: Throwable) {
                Logger.error("${t.message}")
            }

        })

    }
}

private fun showWindowWithDeferred(window: MainWindow) {
    window.onButtonClickScope {
        try {
            val deferred = deferredApi.getUser("zhy060307")
            val user = deferred.await()
            Logger.debug(user)
            window.setButtonText(user.name)
        } catch (e: Exception) {
            Logger.error("error :${e.message}")
        }
    }
}
private fun showWindowWithCoroutine(window: MainWindow) {
    window.onButtonClickScope {
        try {
            val user = suspendApi.getUser("zhy060307")
            Logger.debug(user)
            window.setButtonText(user.name)
        } catch (e: Exception) {
            Logger.error("error :${e.message}")
        }
    }
}