package com.oceanzhao.jvm

import com.oceanzhao.common.callback.User
import kotlinx.coroutines.runBlocking
import retrofit2.Call
import retrofit2.Callback
import retrofit2.HttpException
import retrofit2.Response
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

import kotlin.coroutines.suspendCoroutine
import com.oceanzhao.common.callback.gitHubServiceApi as callbackApi

suspend fun main() {
    runBlocking {
        println(getUser("zhy060307"))
    }
}

suspend fun foo() {
//COROUTINE_SUSPENDED
}
//等价于
//fun foo(continuation: Continuation<Unit>):Any?{
//
//}


suspend fun bar(a: Int): String {
    return "Hello"
}
//等价于
//fun bar(a:Int,continuation: Continuation<String>):Any?{
//    return "Hello"
//}


//回调转换suspend
suspend fun getUser(name: String) = suspendCoroutine<User> { continuation ->
    callbackApi.getUser(name).enqueue(object : Callback<User> {
        override fun onResponse(call: Call<User>, response: Response<User>) {
            response.takeIf { it.isSuccessful }?.body()?.let(continuation::resume)
                ?: continuation.resumeWithException(HttpException(response))
        }

        override fun onFailure(call: Call<User>, t: Throwable) {
            continuation.resumeWithException(t)
        }
    })
}