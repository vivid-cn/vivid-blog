package com.oceanzhao.jvm.T06_Java_Impl

import kotlin.concurrent.thread
import kotlin.coroutines.intrinsics.COROUTINE_SUSPENDED
import kotlin.coroutines.intrinsics.suspendCoroutineUninterceptedOrReturn
import kotlin.coroutines.resume
import com.oceanzhao.common.utils.Logger as log

suspend fun main() {
    log.debug(1)
    log.debug(suspendReturn())
    log.debug(2)
    delay(1000)
    log.debug(3)
    log.debug(immediatelyReturn())
    log.debug(4)


}


suspend fun suspendReturn() = suspendCoroutineUninterceptedOrReturn<String> { continuation ->
    thread(name = "suspendThread") {
        Thread.sleep(1000)
        continuation.resume("suspend return")
    }
    COROUTINE_SUSPENDED
}

suspend fun immediatelyReturn() = suspendCoroutineUninterceptedOrReturn<String> {
    "immediately return"
}