package com.oceanzhao.jvm

import com.oceanzhao.common.callback.User
import com.oceanzhao.common.callback.gitHubServiceApi
import retrofit2.Call
import com.oceanzhao.common.utils.Logger
import retrofit2.Callback
import retrofit2.Response

fun main() {
    gitHubServiceApi.getUser("zhy060307").enqueue(object : Callback<User> {
        override fun onFailure(call: Call<User>, t: Throwable) {
            Logger.error(t)
        }

        override fun onResponse(call: Call<User>, response: Response<User>) {
            if (response.isSuccessful) {
                Logger.debug(response.body())
            } else {
                Logger.error("${response.code()} : ${response.errorBody()}")
            }
        }

    })
}