package com.oceanzhao.jvm.T06_Java_Impl

import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

private val executors = Executors.newScheduledThreadPool(1)
{ r: Runnable ->
    Thread(r, "My-Delay-Scheduler").apply {
        isDaemon = true
    }
}

@JvmOverloads
suspend fun delay(time: Long, unit: TimeUnit = TimeUnit.MILLISECONDS) =
    suspendCoroutine<Unit> { continuation ->
        executors.schedule({
            continuation.resume(Unit)
        }, time, unit)
    }