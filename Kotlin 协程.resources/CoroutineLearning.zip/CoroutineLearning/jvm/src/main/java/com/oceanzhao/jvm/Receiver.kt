package com.oceanzhao.jvm

fun main() {
    println(stringPlus.invoke("1", "2"))
    println(stringPlus.invoke("1", "234"))
    println(intPlus.invoke(1, 2))
    println(intPlus.invoke(1, 234))

    println(fun1(Foo(), "hello1", 1))
    println(fun2.invoke(Foo(), "hello2", 2))

    val foo = Foo()
    val fun3: (String, Int) -> String = foo::bar

}

val stringPlus: (String, String) -> String = String::plus
val intPlus: Int.(Int) -> Int = Int::plus


class Foo {
    fun bar(p0: String, p1: Int): String {
        return "$p0 + $p1"
    }
}

val fun1: Foo.(String, Int) -> String = Foo::bar

var fun2: (Foo, String, Int) -> String = Foo::bar1

fun Foo.bar1(p0: String, p1: Int): String {
    return this.bar(p0, p1) + " $p0 - $p1"
}