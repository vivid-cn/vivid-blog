package com.oceanzhao.jvm

import com.oceanzhao.common.utils.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*

class T08_flow {
}

suspend fun main() {

    exception()

//    backPressure()
}


suspend fun exception() {
    flow<Int> {
        emit(1)
        throw ArithmeticException("Div 0")
    }
        .catch { t: Throwable ->
            Logger.debug("caught error: $t")
        }.onCompletion { t: Throwable? ->
            emit(2)
            Logger.debug("finally.")
        }.flowOn(Dispatchers.IO)
        .collect { Logger.debug(it) }

}


suspend fun backPressure() {
    flow {
        emit(1)
        delay(50)
        emit(2)
    }.collectLatest { value ->
        println("Collecting $value")
        delay(100) // Emulate work
        println("$value collected")
    }
}


suspend fun backPressure1() {
    flow {
        emit(1)
        delay(50)
        emit(2)
    }.conflate()
        .collect { value ->
            println("Collecting $value")
            delay(100) // Emulate work
            println("$value collected")
        }
}