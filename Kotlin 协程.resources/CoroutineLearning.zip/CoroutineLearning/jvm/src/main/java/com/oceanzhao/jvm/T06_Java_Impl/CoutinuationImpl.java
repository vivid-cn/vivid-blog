package com.oceanzhao.jvm.T06_Java_Impl;

import com.oceanzhao.common.utils.Logger;

import org.jetbrains.annotations.NotNull;

import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.intrinsics.IntrinsicsKt;
import kotlin.coroutines.jvm.internal.RunSuspendKt;

public class CoutinuationImpl implements Continuation<Object> {

    private final Continuation<Unit> completion;

    public CoutinuationImpl(Continuation<Unit> completion) {
        this.completion = completion;
    }

    private int label = 0;

    @Override
    public CoroutineContext getContext() {
        return EmptyCoroutineContext.INSTANCE;
    }

    @Override
    public void resumeWith(@NotNull Object o) {
        try {
            Object result = o;
            switch (label) {
                case 0:
                    Logger.INSTANCE.debug(1);
                    result = RunCoroutineKt.suspendReturn(this);
                    label++;
                    if (isSuspended(result)) return;
                case 1:
                    Logger.INSTANCE.debug(result);
                    Logger.INSTANCE.debug(2);
                    DelayKt.delay(1000, this);
                    label++;
                    if (isSuspended(result)) return;
                case 2:
                    Logger.INSTANCE.debug(3);
                    result = RunCoroutineKt.immediatelyReturn(this);
                    label++;
                    if (isSuspended(result)) return;
                case 3:
                    Logger.INSTANCE.debug(result);
                    Logger.INSTANCE.debug(4);
            }
            completion.resumeWith(Unit.INSTANCE);
        } catch (Exception e) {
            completion.resumeWith(e);
        }
    }

    private boolean isSuspended(Object result) {
        return result == IntrinsicsKt.getCOROUTINE_SUSPENDED();
    }

    public static void main(String[] args) throws Throwable {
        RunSuspend runSuspend = new RunSuspend();
        CoutinuationImpl table = new CoutinuationImpl(runSuspend);
        table.resumeWith(Unit.INSTANCE);
        runSuspend.await();
    }
}
