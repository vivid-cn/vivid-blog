package com.oceanzhao.jvm.T06_Java_Impl

import com.oceanzhao.common.utils.Logger
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

fun main() {
    GlobalScope.launch {
        Logger.debug(1)
        Logger.debug(suspendReturn())
        Logger.debug(2)
        Logger.debug(immediatelyReturn())
        Logger.debug(3)
    }
}