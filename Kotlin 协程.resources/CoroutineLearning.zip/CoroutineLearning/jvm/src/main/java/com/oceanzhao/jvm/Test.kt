package com.oceanzhao.jvm

import com.oceanzhao.common.utils.Logger
import kotlinx.coroutines.*
import kotlin.concurrent.thread

fun main() = runBlocking { // this: CoroutineScope
    launch { // launch a new coroutine and continue
//        delay(1000L) // non-blocking delay for 1 second (default time unit is ms)
        Logger.debug("World!") // print after delay
    }
    Logger.debug("Hello") // main coroutine continues while a previous one is delayed
}
private suspend fun testJoin() {
    val job = GlobalScope.launch(start = CoroutineStart.DEFAULT) {

        Logger.debug(1)
        delay(1000)
        Logger.debug(2)
    }
    Logger.debug(3)
    delay(1000)
    job.join()
    Logger.debug(4)//4 shall after 2
}

private suspend fun testLazy() {

    val job = GlobalScope.launch(start = CoroutineStart.LAZY) {
        Logger.debug(1)
        delay(1000)
        Logger.debug(2)
    }
    Logger.debug(3)
    delay(1000)
    job.join()//must call join() or start()
    Logger.debug(4)


    val deferred = GlobalScope.async(start = CoroutineStart.LAZY) {
        Logger.debug(5)
        "Lazy"
    }

    val result = deferred.await()
    Logger.debug("6=$result")

    //same as this
    val thread = thread(start = false) {
        Logger.debug(7)
    }
    thread.start()

}